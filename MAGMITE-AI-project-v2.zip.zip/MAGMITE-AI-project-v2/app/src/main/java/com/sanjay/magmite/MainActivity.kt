package com.sanjay.magmite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MagmiteScreen() }
    }
}

@Composable
fun MagmiteScreen() {
    var status by remember { mutableStateOf("READY FOR COMMAND") }
    val infinite = rememberInfiniteTransition(label = "core")
    val rotation by infinite.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "rotation"
    )
    val pulse by infinite.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
        animation = tween(
            durationMillis = 1300,
            easing = FastOutSlowInEasing
        ),
        repeatMode = RepeatMode.Reverse
    ),
    label = "pulse"
)

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF050505)).padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(28.dp))
            Text("MAGMITE", color = Color(0xFFFF5A1F), fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
            Text("AI CORE // ONLINE", color = Color(0xFF9A9A9A), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(36.dp))

            Box(
                modifier = Modifier.size(250.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier.fillMaxSize().rotate(rotation)
                ) {
                    val c = center
                    drawCircle(Color(0x33FF4A00), 105.dp.toPx(), c)
                    drawCircle(Color(0xFFFF4A00), 92.dp.toPx(), c, style = Stroke(2.dp.toPx()))
                    drawCircle(Color(0x66FFB000), 75.dp.toPx(), c, style = Stroke(3.dp.toPx()))
                    drawLine(Color(0xFFFF5A1F), Offset(c.x - 115.dp.toPx(), c.y), Offset(c.x - 80.dp.toPx(), c.y), 3.dp.toPx())
                    drawLine(Color(0xFFFF5A1F), Offset(c.x + 80.dp.toPx(), c.y), Offset(c.x + 115.dp.toPx(), c.y), 3.dp.toPx())
                }
                Box(
                    modifier = Modifier
                        .size((92 * pulse).dp)
                        .background(
                            Brush.radialGradient(listOf(Color(0xFFFFC04D), Color(0xFFFF4A00), Color(0xFF350800))),
                            CircleShape
                        )
                        .border(2.dp, Color(0xFFFFB000), CircleShape)
                )
            }

            Spacer(Modifier.height(28.dp))
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF4A2619), RoundedCornerShape(14.dp)).padding(16.dp)
            ) {
                Column {
                    Text("SYSTEM STATUS", color = Color(0xFFFF5A1F), fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("MAGMITE intelligence core is active.", color = Color(0xFF8A8A8A), fontSize = 12.sp)
                }
            }

            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .border(1.dp, Color(0xFFFF5A1F), RoundedCornerShape(18.dp))
                    .clickable { status = "LISTENING..." },
                contentAlignment = Alignment.Center
            ) {
                Text("◉   TAP TO SPEAK", color = Color(0xFFFF7A38), fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}
